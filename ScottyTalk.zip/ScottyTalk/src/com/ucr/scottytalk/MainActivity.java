package com.ucr.scottytalk;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;


public class MainActivity extends Activity {
	
	public final static String EXTRA_MESSAGE = "com.ucr.scottytalk.MESSAGE";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);	    
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_menu_, menu);
		return true;
	}
	
	//Function that handles the Login button
    public void menu(View view){
    	Intent intent = new Intent (this, LogIn.class); 
    	startActivity (intent);
    }
/*
    public void register(View view){
    	Intent intent = new Intent (this, Register_Activity.class); 
    	startActivity (intent);
    }
*/
}
