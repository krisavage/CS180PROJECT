/** Automatically generated file. DO NOT MODIFY */
package com.ucr.scottytalk;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}